TROP MARKET UGANDA — ANDROID APP BUILDER KIT
Developer: Agona Peter
Website: https://milesbrownxx-creator.github.io/-trop-market-uganda/

IMPORTANT
This kit contains Android app source and a GitHub Actions workflow that builds an installable APK for you. It is not itself an APK yet. GitHub Actions builds the APK online after you upload the source ZIP and workflow. This avoids needing a computer or Android Studio.

FILES IN THIS KIT
1. TROP-Market-Uganda-Android-App-Source.zip — the Android app project.
2. build-android-app.yml — the workflow file GitHub uses to build the APK.

PART 1 — UPLOAD THE SOURCE ZIP
1. Download and extract this builder-kit ZIP using My Files on your Samsung phone.
2. Open https://github.com/milesbrownxx-creator/-trop-market-uganda
3. Make sure the repository is public and you are signed in.
4. Tap Add file, then Upload files.
5. Select the file named TROP-Market-Uganda-Android-App-Source.zip from the extracted kit. Upload that ZIP itself to the repository's top/root level (not inside a folder).
6. Commit changes to the main branch (or master if that is the branch GitHub shows).

PART 2 — ADD THE BUILD WORKFLOW
1. Return to the repository homepage.
2. Tap Add file, then Create new file.
3. In the filename box, enter exactly:
   .github/workflows/build-android-app.yml
4. Open the separate file named build-android-app.yml from this kit in a text editor, select and copy all its text, and paste it into GitHub's editor.
5. Tap Commit changes. Use the main branch (or the branch that the repository uses).
6. This commit should start the build automatically. If it does not, open the Actions tab, choose Build TROP Market Android APK, tap Run workflow, and confirm Run workflow.

PART 3 — DOWNLOAD THE APK
1. In GitHub, open the Actions tab.
2. Open the newest "Build TROP Market Android APK" run.
3. Wait until the build finishes with a green check. If it fails, open the run and copy the red error text for help.
4. Scroll to Artifacts and tap TROP-Market-Uganda-APK to download it. GitHub downloads an artifact ZIP. Extract that artifact ZIP in My Files to get TROP-Market-Uganda.apk.
5. Tap TROP-Market-Uganda.apk. Android may ask you to allow installation from this source; allow it for the app you used to open the APK, then return and install.

WHAT THIS APP DOES
- Opens your existing live TROP Market Uganda website in a standalone Android app window.
- Uses the TROP shopping-bag app icon and app name.
- Shows an offline/retry message if the website cannot load.
- Keeps TROP Market pages in the app and opens external product/checkout links in the browser.
- Website updates remain online; the app needs internet to load current products and pages.

LIMITATIONS
- This produces a debug APK for testing and direct installation, not a Play Store-ready signed release. Publishing on Google Play requires a release build and signing setup.
- This wrapper does not repair product/catalogue/backend issues in the website itself.
- The builder file contains no passwords or secret keys. Keep any private credentials out of the repository.
